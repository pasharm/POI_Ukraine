# POI Ukraine for JOSM

Tagging preset for Ukrainian shops and amenities.
Заготовки для додавання магазинів та інших закладів України.
Заготовки для добавления магазинов и иных заведений Украины.
